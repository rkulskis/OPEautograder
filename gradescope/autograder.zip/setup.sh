#!/usr/bin/env bash

apt-get install -y zip
